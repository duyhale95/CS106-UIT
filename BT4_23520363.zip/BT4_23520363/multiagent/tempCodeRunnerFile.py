import os
import subprocess

# Tạo file result.txt
with open("result.txt", "w") as f:
    f.write("Kết quả chạy các thuật toán\n")
    f.write("===========================\n\n")

# Lấy danh sách layout từ thư mục layouts
layout_dir = os.path.join('layouts')
layouts = [f for f in os.listdir(layout_dir) if f.endswith('.lay')]

algorithms = ['MinimaxAgent', 'AlphaBetaAgent', 'ExpectimaxAgent']
functions = ['myEvaluationFunction', 'betterEvaluationFunction']

# Chạy các thuật toán
for func in functions:
    for level in layouts:
        for al in algorithms:
            print(f"Chạy {al} với {func} trên map {level[:-4]}")
            
            # Ghi thông tin vào result.txt
            with open("result.txt", "a") as f:
                f.write(f"Chạy {al} với {func} trên map {level[:-4]}\n")
            
            # Chạy pacman và lưu kết quả
            command = f'python pacman.py -n 5 -l {level[:-4]} -p {al} -a depth=2,evalFn={func} -q'
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            
            # Ghi kết quả vào file
            with open("result.txt", "a") as f:
                f.write(result.stdout)
                f.write("\n")

print("Hoàn thành chạy thử nghiệm!")
with open("result.txt", "a") as f:
    f.write("Hoàn thành chạy thử nghiệm!\n")