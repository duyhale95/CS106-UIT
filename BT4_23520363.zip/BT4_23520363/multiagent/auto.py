import os
import random
layout = os.listdir('D:\multi-agent\multiagent\layouts')
random_layouts = random.sample(layout, 5)
algorithms = ['MinimaxAgent', 'AlphaBetaAgent', 'ExpectimaxAgent']
functions = ['myEvaluationFunction', 'scoreEvaluationFunction']
for func in functions:
    for level in random_layouts:
        for al in algorithms:
            command = f'python pacman.py -n 5 -l {level[:-4]} -p {al} -a depth=2,evalFn={func} -q --frameTime 0\n'
            f = open("script.sh", "a")
            f.write(command)
            f.close()