"""
Module đọc dữ liệu từ file test case
"""

import random

def read_test_case(file_path):
    """
    Đọc dữ liệu từ file test case
    
    Args:
        file_path: Đường dẫn đến file test case
        
    Returns:
        tuple: (values, weights, capacity, test_file_path)
    """
    arr = {}
    arr['weight'] = []
    arr['values'] = []
    
    # Chọn ngẫu nhiên file test case từ 000 đến 099
    random_number = random.randint(0, 99)
    test_file = f's{random_number:03d}.kp'
    test_file_path = f'/R01000/{test_file}'
    
    with open(file_path + test_file_path, 'rb') as file:
        data = file.read()

    f = data.split(b'\n')
    decoded_lines = []
    for line in f:
        # Loại bỏ \r và khoảng trắng thừa
        cleaned_line = line.decode('utf-8').strip().replace('\r', '')
        if cleaned_line:  # Chỉ thêm vào nếu dòng không rỗng
            decoded_lines.append(cleaned_line)

    n = 0
    c = 0
    for line in range(len(decoded_lines)):
        try:
            numbers = [int(x) for x in decoded_lines[line].split() if x]
            if not numbers:
                continue
            if len(numbers) == 1:
                if n == 0:
                    n = numbers[0]
                else:
                    c = numbers[0]
            else:
                arr['values'].append(numbers[0])
                arr['weight'].append(numbers[1])
        except ValueError:
            continue

    values = arr['values']
    weights = arr['weight']
    capacities = c

    return values, [weights], [capacities], test_file_path 