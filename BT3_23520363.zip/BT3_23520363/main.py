"""
Chương trình chính giải bài toán Knapsack
"""

import os
from data_reader import read_test_case
from solver import solve_knapsack

def choose_group():
    """
    Cho phép người dùng chọn nhóm dữ liệu để chạy
    """
    groups = {
        0: "00Uncorrelated",
        1: "01WeaklyCorrelated",
        2: "02StronglyCorrelated",
        3: "03InverseStronglyCorrelated",
        4: "04AlmostStronglyCorrelated",
        5: "05SubsetSum",
        6: "06UncorrelatedWithSimilarWeights",
        7: "07SpannerUncorrelated",
        8: "08SpannerWeaklyCorrelated",
        9: "09SpannerStronglyCorrelated",
        10: "10MultipleStronglyCorrelated",
        11: "11ProfitCeiling",
        12: "12Circle"
    }
    
    print("Chọn nhóm dữ liệu:")
    for key, value in groups.items():
        print(f"{key}: {value}")
    
    while True:
        try:
            choice = int(input("Nhập số từ 0-12: "))
            if 0 <= choice <= 12:
                return groups[choice], f"./kplib/{groups[choice]}/"
            print("Vui lòng nhập số từ 0 đến 12!")
        except ValueError:
            print("Vui lòng nhập một số hợp lệ!")

def main():
    # Cho người dùng chọn nhóm dữ liệu
    group_name, path = choose_group()
    
    # Danh sách các test case
    test_cases = ['n00050', 'n00100', 'n00200', 'n00500', 'n01000', 'n02000']

    with open(f'{group_name}.txt', 'a') as f:
        f.write(f'Group: {path}\n')

        from tabulate import tabulate

        for test_case in test_cases:
            f.write(f'Test case: {test_case}\n')

            # Đọc dữ liệu
            values, weights, capacity, test_file_path = read_test_case(path + test_case)

            # Giải bài toán
            total_value, packed_items, packed_weights, run_time, is_optimal = solve_knapsack(
                values, weights[0], capacity[0]
            )

            # Tạo bảng kết quả ngắn gọn
            table = [
                ["Test file path", test_file_path],
                ["Total value", total_value],
                ["Total weight", sum(packed_weights)],
                ["Execution time (s)", f"{run_time:.4f}"],
                ["Number of packed items", len(packed_items)],
                ["Is optimal", is_optimal]
            ]

            pretty_table = tabulate(table, headers=["Field", "Value"], tablefmt="grid")

            # Ghi vào file
            f.write(pretty_table + "\n\n")
            f.write("Packed items: " + ', '.join(map(str, packed_items)) + "\n")
            f.write("Packed weights: " + ', '.join(map(str, packed_weights)) + "\n")
            f.write('-' * 90 + '\n\n')
        
        f.write('\n\n')
        f.write('*******************************************************************************************')
        f.write('\n')
        f.write('*******************************************************************************************')
        f.write('\n\n')

if __name__ == "__main__":
    main() 