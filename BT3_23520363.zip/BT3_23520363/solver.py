"""
Module giải bài toán Knapsack sử dụng OR-Tools
"""

from ortools.algorithms.python import knapsack_solver
import time
def solve_knapsack(values, weights, capacity):
    """
    Giải bài toán Knapsack sử dụng thuật toán Branch and Bound
    
    Args:
        values: Danh sách giá trị của các items
        weights: Danh sách trọng lượng của các items
        capacity: Sức chứa của balo
        
    Returns:
        tuple: (total_value, packed_items, packed_weights, run_time, is_optimal)
            - total_value: Tổng giá trị của các items được chọn
            - packed_items: Danh sách chỉ số của các items được chọn
            - packed_weights: Danh sách trọng lượng của các items được chọn
            - run_time: Thời gian chạy thuật toán (giây)
            - is_optimal: Kết quả có tối ưu hay không
    """
    # Tạo solver
    solver = knapsack_solver.KnapsackSolver(
        knapsack_solver.SolverType.KNAPSACK_MULTIDIMENSION_BRANCH_AND_BOUND_SOLVER,
        "KnapsackSolver"
    )
    
    # Đặt thời gian chạy tối đa
    solver.set_time_limit(180)
    
    # Khởi tạo solver với dữ liệu
    solver.init(values, [weights], [capacity])
    
    # Bắt đầu đo thời gian
    start_time = time.time()
    
    # Giải bài toán
    total_value = solver.solve()
    
    # Kết thúc đo thời gian
    end_time = time.time()
    run_time = end_time - start_time
    
    # Lấy danh sách items được chọn
    packed_items = []
    packed_weights = []
    
    for i in range(len(values)):
        if solver.best_solution_contains(i):
            packed_items.append(i)
            packed_weights.append(weights[i])
    
    # Kiểm tra tính tối ưu
    is_optimal = solver.is_solution_optimal()
    
    return total_value, packed_items, packed_weights, run_time, is_optimal 